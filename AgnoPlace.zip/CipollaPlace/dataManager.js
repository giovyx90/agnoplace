const fs = require('fs');

const dataFilePath = './pixels.json';

// Funzione per caricare i dati dei pixel dal file JSON
function loadPixelsData() {
  try {
    const data = fs.readFileSync(dataFilePath, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error loading pixels data:', err);
    return { pixels: [] };
  }
}

// Funzione per salvare i dati dei pixel nel file JSON
function savePixelsData(pixelsData) {
  try {
    const data = JSON.stringify(pixelsData, null, 2);
    fs.writeFileSync(dataFilePath, data, 'utf8');
    console.log('Pixels data saved successfully.');
  } catch (err) {
    console.error('Error saving pixels data:', err);
  }
}

module.exports = {
  loadPixelsData,
  savePixelsData,
};
